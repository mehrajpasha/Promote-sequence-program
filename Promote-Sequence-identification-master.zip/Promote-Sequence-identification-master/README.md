# Promote Sequence identification

A Python program to identify promoter region of a given DNA sequence
## The sample output for the given program:

![Promoter output]( https://github.com/TejaSreenivas/Promote-Sequence-identification/blob/master/promoter_profile_for_seq_15.png)

